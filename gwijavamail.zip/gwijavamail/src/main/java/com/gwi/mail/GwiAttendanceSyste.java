package com.gwi.mail;

import com.gwi.mail.ui.GwiFileChooser;

import javax.swing.JFrame;

public class GwiAttendanceSyste extends JFrame {
    public static void main(String[] args) throws Exception {
        System.out.println("GwiAttendanceSyste");
        new GwiFileChooser();
    }
}
